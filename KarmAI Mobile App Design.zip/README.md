
  # KarmAI Mobile App Design

  This is a code bundle for KarmAI Mobile App Design. The original project is available at https://www.figma.com/design/kZNcMmrVBWjoEIKHwGagJr/KarmAI-Mobile-App-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  